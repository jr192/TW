function checkLogin()
{
    var nameRegex = /^[a-zA-Z0-9\_]+$/;
    var username_teste = document.getElementById('user').value;
    var password_teste= document.getElementById('pass').value;
    var match = document.getElementById('user').value.match(nameRegex);
    
    if(username_teste.length === 0)
    {
        alert("Your username is empty!");
        return false;      
    }
    
    if(match === null)
    {
        alert("Your username is not valid. Only characters A-Z, a-z and '_' are  acceptable.");
        return false;
    }
    
    if(username_teste.length > 15)
    {
        alert("You have more than 15 characters on username!");
        return false;
    }
    
    if(password_teste.length === 0)
    {
        alert("Your password is empty!");
        return false;
    }
    
    if(password_teste.length < 4)
    {
        alert("Your password is too small!");
        return false;
    }
    
    document.getElementById('user').innerHTML = username_teste;
    return true;
}
	
//------------------------------------------------------------
//							REGISTER						//
//------------------------------------------------------------
function register(){
	var user = document.getElementById("user").value;
	var pass = document.getElementById("pass").value;
	
	if(checkLogin()){
		
		var xhr = new XMLHttpRequest();
        xhr.open("POST","http://twserver.alunos.dcc.fc.up.pt:8008/register",true);
        xhr.onreadystatechange = function() {
        	
        	if(xhr.readyState < 4)
                return;
            if(xhr.status == 200){ //faz login
                var resposta = JSON.parse(xhr.responseText);
                username = name;
                password = pass;
                document.getElementById('painel_login').style.display = 'none';
                document.getElementById('jogo_on').style.display = 'none';
                document.getElementById('painel_jogo').style.display = 'block';
            }
            else{
                    alert("Password errada!");
                    document.getElementById("my_login").reset();
            }
        }    
        xhr.send(JSON.stringify({"nick": user,"pass": pass}));    
	}
	else{
        document.getElementById("my_login").reset();
	}		
}
//------------------------------------------------------------
//							JOIN							//
//------------------------------------------------------------
function join(){
		var group = "19";
		 user = document.getElementById("user").value;
		 pass = document.getElementById("pass").value;
		size = "5"; // por mudar
		console.log("Username: "+ user + "| Password: "+pass);

        var xhr = new XMLHttpRequest();
        
        xhr.open("POST","http://twserver.alunos.dcc.fc.up.pt:8008/join",true);
        xhr.onreadystatechange = function() {
        	
            if(xhr.readyState < 4)
                return;
            if(xhr.status == 200){ 
                 var game_ash = JSON.parse(xhr.responseText);
                 game=game_ash.game;
                 update(user,game);
                 wait = 1;
            }
        }
        xhr.send(JSON.stringify({"group": group,"nick": user,"pass": pass, "size": size}));    
}
//------------------------------------------------------------
//							UPDATE							//
//------------------------------------------------------------
function update(user,game){
    var xhr = new XMLHttpRequest();
    console.log("ON UPDATE");
    xhr.open("GET",'http://twserver.alunos.dcc.fc.up.pt:8008/update?nick='+user+'&game='+ game,true);
    var eventSource = new EventSource('http://twserver.alunos.dcc.fc.up.pt:8008/update?'+'nick='+user + '&game='+ game);
    var flag = 0;
    eventSource.onmessage = function(event) {
        evdata =  JSON.parse(event.data);
        rack=evdata.rack;
        rack.reverse();
        console.log(evdata);
        
       
        if(wait==1){
        	
        	mode = 1;
        	wait = 0;
        	gerar_tab(evdata.rack);

        }
        else {
        	console.log(evdata);
        	update_tab(evdata.rack);
        }
//        else  if(evdata.turn == user){
//        	console.log(evdata);
//        	turn = 0;
//
//        }	
    }
}

//------------------------------------------------------------
//							NOTIFY							//
//------------------------------------------------------------
function notify(stack_2,pieces_2){
	 user = document.getElementById("user").value;
	 pass = document.getElementById("pass").value;
	 stack = stack_2;
	 pieces = pieces_2;
	
    var xhr = new XMLHttpRequest();
    //var game_ash = JSON.parse(xhr.responseText);
    //var game=game_ash.game;
    xhr.open("POST","http://twserver.alunos.dcc.fc.up.pt:8008/notify",true);
    xhr.onreadystatechange = function() {  
    	 if(xhr.readyState < 4)
             return;
         if(xhr.status == 200){ 
              var notify = JSON.parse(xhr.responseText);
         }
    }
    xhr.send(JSON.stringify({"nick": user,"pass":pass,"game": game, "stack": stack,"pieces":pieces}));
}
