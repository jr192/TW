var flag = 0; // 1 PC & 0 User
var size = 0;
var tam=size;
var nim = 0;
var game_ash;
function register(){

	
	    var name = document.getElementById("user").value;
	    var pass = document.getElementById("pass").value;
	    
	    if(checkLogin()){
	  
	    	 	var xhr = new XMLHttpRequest();

	    	    xhr.open("POST","http://twserver.alunos.dcc.fc.up.pt:8008/register",true);
	    	    xhr.onreadystatechange = function() {
	    	        if(xhr.readyState < 4)
	    	            return;
	    	        if(xhr.status == 200){ //faz login
	    	            var resposta = JSON.parse(xhr.responseText);
	    	            document.getElementById('painel_login').style.display = 'none';
	    	            document.getElementById('jogo_on').style.display = 'none';
	    	        		document.getElementById('painel_jogo').style.display = 'block';

	    	        }
	    	        else{
	    	        		alert("Password errada!");
	    	        		document.getElementById("my_login").reset();
	    	        }
	    	        
	    	    }    
	    	    xhr.send(JSON.stringify({"nick": name,"pass": pass}));    
	    }
	    else{
    			document.getElementById("my_login").reset();

	    }

}
function checkLogin()
{
    var nameRegex = /^[a-zA-Z0-9\_]+$/;
    var username_teste = document.getElementById('user').value;
    var password_teste= document.getElementById('pass').value;
    var match = document.getElementById('user').value.match(nameRegex);
    
    if(username_teste.length === 0)
    {
        alert("Your username is empty!");
        return false;      
    }
    
    if(match === null)
    {
        alert("Your username is not valid. Only characters A-Z, a-z and '_' are  acceptable.");
        return false;
    }
    
    if(username_teste.length > 15)
    {
        alert("You have more than 15 characters on username!");
        return false;
    }
    
    if(password_teste.length === 0)
    {
        alert("Your password is empty!");
        return false;
    }
    
    if(password_teste.length < 4)
    {
        alert("Your password is too small!");
        return false;
    }
    
    document.getElementById('user').innerHTML = username_teste;
    return true;
}
	
function join(){
	
	    var group = "19";
	    var name = document.getElementById("user").value;
	    var pass = document.getElementById("pass").value;
	    size = "5";
	    	
	 	    	 	var xhr = new XMLHttpRequest();

	 	    	    xhr.open("POST","http://twserver.alunos.dcc.fc.up.pt:8008/join",true);
	 	    	    xhr.onreadystatechange = function() {
	 	    	        if(xhr.readyState < 4)
	 	    	            return;
	 	    	        if(xhr.status == 200){	
	 	    	             game_ash = JSON.parse(xhr.responseText); 
	 	    	             update(game_ash,name);
	 	    	             
	 	    	        }
	 	    	    }    
	 	    	    xhr.send(JSON.stringify({"group": group,"nick": name,"pass": pass, "size": size}));    
	 	    
}
	
function update(game_ash,name){
	var ash=game_ash.game;
	var xhr = new XMLHttpRequest();
	console.log(ash + "SIZENOUPDATE:" + size);
	 var eventSource = new EventSource('http://twserver.alunos.dcc.fc.up.pt:8008/update?'+'nick='+name + '&game='+ ash);
	 eventSource.onmessage = function(event) {
		 var evdata =  JSON.parse(event.data);
		 console.log("quem está a jogar: " + evdata.turn);
		 console.log(" joga em que coluna: " + evdata.rack);
		 
		   myFunction(size);
		   notify();
		    xhr.open("GET","http://twserver.alunos.dcc.fc.up.pt:8008/update",true);
		   /* xhr.onreadystatechange = function() {
		    	console.log("FASDASDaasdasdasdw"); *     
		        if(xhr.status === onmessage){	
		        	 var reposta = JSON.parse(xhr.responseText);
		        	 //console.log(resposta);
		        	 /*console.log(resposta.rack);
			        	 if(resposta.turn !== undefined)
			        	 {
			        		 rack = resposta.rack;
			        		 turn = resposta.turn;
			        		 
			        		 
			        	}
			        	  if(resposta.winner !== undefined)
			        	 {
			        		 alert("winner:" + resposta.winner);
				    	}
		        }
		    }
	 }*/
	 eventSource.close();
	
}
}

function notify(){
    var name = document.getElementById("user").value;
    var pass = document.getElementById("pass").value;
    var game = game_ash.game;
    var stack = "2";
    var pieces ="2";
    	
    console.log("asd:" + game);
 	    	 	var xhr = new XMLHttpRequest();

 	    	    xhr.open("POST","http://twserver.alunos.dcc.fc.up.pt:8008/notify",true);
 	    	    xhr.onreadystatechange = function() {	
 	    	        if(xhr.readyState < 4)
 	    	            return;
 	    	        if(xhr.status == 200){	
 	    	             var notify = JSON.parse(xhr.responseText);
 	    	             //update(game_ash,name);
 	    	             console.log("peças " + notify.pieces + "stack" + notify.stack);
 	    	        }
 	    	    }    
 	    	    xhr.send(JSON.stringify({"nick": name,"pass":pass,"game": game, "stack": stack,"pieces":pieces}));   
}




function gerar_tab(size) {
	document.getElementById('jogo_on').style.display = 'none';

	document.getElementById('tabuleiro').style.display = 'block';

	document.getElementById('play').style.display = 'inline-block';
	document.getElementById('quit').style.display = 'inline-block';
	tam=size;
	nim = tam * tam;
	console.log("NIM " + nim + "TAM " + tam);
	var table = document.getElementById('tableclass');
	console.log("= " + tam);
	for (var i = 0; i < tam; i++) {
		var row = table.insertRow();
		row.classList.add('tr');

		for (var j = 0; j < tam; j++) {
			var td = row.insertCell();
			td.classList.add('td');
			cell_onclick(td, i, j);
		}
	}
	if (flag != 0)
		setTimeout(pc_play, 100);

}

function gerar_tab2() {
	var table = document.getElementById('tabelaclassificacao');

	for (var i = 0; i < 11 ;i++) {
		var row = table.insertRow();
		row.classList.add('tr_1');

		for (var j = 0; j < 2 ;j++) {
			var td = row.insertCell();
			td.classList.add('td_1');

		}
	}
	var n = "Nome";
	var t = "Tempo";
	document.getElementById("tabelaclassificacao").rows[0].cells[0].innerHTML = n;
	document.getElementById("tabelaclassificacao").rows[0].cells[1].innerHTML = t;


	for ( i = 1; i <= 10 ;i++) {
		var player_class = i  + 'º		--------------		';
		var player_time = "-- / -- / --";
		console.log(player_class);
			document.getElementById("tabelaclassificacao").rows[i].cells[0].innerHTML = player_class;
			document.getElementById("tabelaclassificacao").rows[i].cells[1].innerHTML = player_time;

	}

}


function getCell(l, c) {
	var boardElement = document.getElementById("tableclass");
	return boardElement.rows[l].cells[c];
}

function pc_play() {
	document.getElementById('demo_3').style.display = 'none';

	var x, y;
	var cell;
	// alert(nim);

	if (nim <= 0)
		return;

	do {
		x = Math.floor((Math.random() * tam));
		y = Math.floor((Math.random() * tam));
		// console.log(x + " " + y + " " + tam);
	} while (getCell(x, y).className != "td");

	for (var i = x; i >= 0; i--) {
		var cell_vizinha = getCell(i, y);
		if (cell_vizinha.className == "inactive")
			break;
		cell_vizinha.className = "temporario";

	}

	setTimeout(function() {
		for (var i = x; i >= 0; i--) {
			var cell_vizinha = getCell(i, y);
			if (cell_vizinha.className == "inactive")
				break;
			cell_vizinha.className = "inactive";
			nim--;

		}
		winner();

		flag = 0;
	}, 1000);
}

function winner() {
	if (nim <= 0) {
		if (flag == 0) {
			alert("Parabéns, ganhaste!");

		} else {
			alert("Perdeste, tente de novo!");

		}

		document.getElementById('tabuleiro').style.display = 'none';
		document.getElementById('gerar_tab').style.display = 'none';
		// document.getElementById('myFunction').style.display = 'none';
		document.getElementById('quit').style.display = 'none';
		document.getElementById('play').style.display = 'none';
		document.getElementById('try_again').style.display = 'block';

		return;
	}
}

function cell_onclick(cell, l, c) {

	cell.onclick = function() {
		if (flag == 0 && cell.className == "td") {
			for (var i = l; i >= 0; i--) {
				var cell_vizinha = getCell(i, c);
				if (cell_vizinha.className == "inactive")
					break;

				cell_vizinha.className = "inactive";
				nim--;

			}
			// nim = nim - (l + 1);

			winner();
			flag = 1;
			setTimeout(pc_play, 3);
		}
	}

	cell.onmouseover = function() {
		if (cell.className !== "inactive" && cell.className !== "temporario")
			for (var i = l - 1; i >= 0; i--) {
				var cell_vizinha = getCell(i, c);
				if (cell_vizinha.className == "inactive"
						|| cell_vizinha.className == "temporario")
					break;
				cell_vizinha.className = "active";
			}
	}

	cell.onmouseout = function() {
		if (cell.className !== "inactive" && cell.className !== "temporario")
			for (var i = l; i >= 0; i--) {
				var cell_vizinha = getCell(i, c);
				if (cell_vizinha.className == "inactive"
						|| cell_vizinha.className == "temporario")
					break;
				cell_vizinha.className = "td";
			}
	}

}

function clearBoard() {

	var i;
	for (i = 0; i < tam; i++) {
		if (document.getElementById("tableclass").rows.length != 0)
			document.getElementById("tableclass").deleteRow(0);
	}
}
function clearBoard_rank() {

	var i;
	for (i = 0; i < 10; i++) {
		if (document.getElementById("tabelaclassificacao").rows.length != 0)
			document.getElementById("tabelaclassificacao").deleteRow(0);

	}
}

function myFunction(size) {
	var x, text;
	
	x = document.getElementById("numb").value;
	document.getElementById('demo_3').style.display = 'none';
	document.getElementById('gerar_tab').style.display = 'block';
	tam = x;
	//clearBoard();
	gerar_tab(size);
}

function first_play() {
	document.getElementById('demo').style.display = 'none';
	document.getElementById('demo_2').style.display = 'block';

	flag = 0// user

}
function first_play_pc() {
	document.getElementById('demo').style.display = 'none';
	document.getElementById('demo_2').style.display = 'block';

	flag = 1; // pc

}

function dif_play() {
	document.getElementById('demo_2').style.display = 'none';
	document.getElementById('demo_3').style.display = 'block';

}
function registar() {
	document.getElementById('header_painel2').style.display = 'none';
	document.getElementById('painel_login').style.display = 'block';
}

function login() {
	document.getElementById('painel_rank').style.display = 'none';
	document.getElementById('painel_instrucoes').style.display = 'none';
	document.getElementById('gerar_tab').style.display = 'none';
	document.getElementById('painel_jogo').style.display = 'none';
	document.getElementById('tabuleiro').style.display = 'none';
	document.getElementById('painel_init').style.display = 'none';
	document.getElementById('painel_login').style.display = 'block';
}
function login_wData() {
	document.getElementById('painel_login').style.display = 'none';
	document.getElementById('painel_init').style.display = 'block';
}
function config() {
	clearBoard();
	document.getElementById('painel_login').style.display = 'none';
	document.getElementById('painel_rank').style.display = 'none';
	document.getElementById('painel_init').style.display = 'none';
	document.getElementById('painel_instrucoes').style.display = 'none';
	document.getElementById('gerar_tab').style.display = 'none';
	document.getElementById('painel_jogo').style.display = 'block';
	document.getElementById('tabuleiro').style.display = 'none';

}
function modo_jogo() {
	document.getElementById('gerar_tab').style.display = 'none';
	document.getElementById('modo_jogo').style.display = 'none';
	document.getElementById('jogo_on').style.display = 'none';

	document.getElementById('demo').style.display = 'block';
}
function modo_online_jogo() {
	document.getElementById('modo_jogo').style.display = 'none';

	document.getElementById('jogo_on').style.display = 'block';
	//join();

}
function instrucoes() {
	document.getElementById('gerar_tab').style.display = 'none';
	document.getElementById('painel_jogo').style.display = 'none';
	document.getElementById('painel_login').style.display = 'none';
	document.getElementById('painel_init').style.display = 'none';
	document.getElementById('painel_rank').style.display = 'none';
	document.getElementById('painel_instrucoes').style.display = 'block';

}
function rank() {
	document.getElementById('gerar_tab').style.display = 'none';
	document.getElementById('painel_jogo').style.display = 'none';
	document.getElementById('painel_login').style.display = 'none';
	document.getElementById('painel_init').style.display = 'none';
	document.getElementById('painel_instrucoes').style.display = 'none';
	document.getElementById('gerar_tab').style.display = 'none';
	clearBoard_rank();
	document.getElementById('painel_rank').style.display = 'block';
	gerar_tab2();
	document.getElementById('tabelaclassificacao').style.display = 'block';

}

function home() {
	clearBoard();
	document.getElementById('tabuleiro').style.display = 'none';
	document.getElementById('quitgame').style.display = 'none';
	document.getElementById('gerar_tab').style.display = 'none';
	document.getElementById('painel_jogo').style.display = 'none';
	document.getElementById('painel_instrucoes').style.display = 'none';
	document.getElementById('painel_login').style.display = 'none';
	document.getElementById('painel_rank').style.display = 'none';
	document.getElementById('painel_init').style.display = 'block';
	//document.getElementById('demo').style.display = 'block';
	
}
function table_click() {
	var boardElement = document.getElementById("tabuleiro");
	alert(boardElement.rows[l].cells[c]);
}

function try_again() {
	clearBoard();
	document.getElementById('try_again').style.display = 'none';
	document.getElementById('demo').style.display = 'block';
}
function playbutton(){
	document.getElementById('painel_login').style.display = 'none';
	document.getElementById('painel_rank').style.display = 'none';
	document.getElementById('painel_init').style.display = 'none';
	document.getElementById('painel_instrucoes').style.display = 'none';
	document.getElementById('gerar_tab').style.display = 'block';
	document.getElementById('painel_jogo').style.display = 'block';
	document.getElementById('tabuleiro').style.display = 'block';
}
function quitbutton(){
	document.getElementById('play').style.display = 'none';
	document.getElementById('quit').style.display = 'none';
	document.getElementById('painel_jogo').style.display = 'none';
	document.getElementById('gerar_tab').style.display = 'none';
	document.getElementById('tabuleiro').style.display = 'none';
	document.getElementById('quitgame').style.display = 'block';
}
function yes(){
	clearBoard();
	document.getElementById('tabuleiro').style.display = 'none';
	document.getElementById('quitgame').style.display = 'none';
	document.getElementById('painel_jogo').style.display = 'none';
	document.getElementById('painel_init').style.display = 'block';
	document.getElementById('demo').style.display = 'block';

	}
function quitfunction(){
	document.getElementById('play').style.display = 'block';
	document.getElementById('quitgame').style.display = 'none';
	document.getElementById('quit').style.display = 'block';
	document.getElementById('painel_jogo').style.display = 'block';
	document.getElementById('tabuleiro').style.display = 'block';
	document.getElementById('gerar_tab').style.display = 'block';

}	
